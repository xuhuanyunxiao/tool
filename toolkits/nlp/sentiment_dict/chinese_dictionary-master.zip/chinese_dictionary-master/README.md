# chinese_dictionary
同义词表，反义词表，否定词表
